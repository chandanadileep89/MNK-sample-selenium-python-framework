
import os
from datetime import datetime
import pytest
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
@pytest.fixture(scope="session")
def setup():
    chrome_options = Options()

    chrome_options.add_experimental_option(
        "prefs",
        {
            "credentials_enable_service": False,
            "profile.password_manager_enabled": False,
            "profile.password_manager_leak_detection": False  # ✅ IMPORTANT
        }
    )

    chrome_options.add_argument("--disable-features=PasswordLeakDetection")
    chrome_options.add_argument("--disable-infobars")
    chrome_options.add_experimental_option(
        "excludeSwitches", ["enable-automation"]
    )

    service = ChromeService(ChromeDriverManager().install())
    driver = webdriver.Chrome(service=service, options=chrome_options)
    driver.maximize_window()
    yield driver
    driver.quit()


@pytest.fixture
def screenshot_dir():
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    path = os.path.join(os.getcwd(), "screenshots", timestamp)
    #os.makedirs(path, exist_ok=True)
    #filename=os.path.join(path,f"{timestamp}.html")
    return path

# @pytest.fixture()
# def browser(request):
#     request.config.getoption("--browser--")


#
# @pytest.fixture(scope="session")
# def generatedhtmlreports(pytestconfig):
#     """Returns the final generated report path if needed in tests."""
#     return pytestconfig.getoption("htmlpath")





# @pytest.hookimpl(tryfirst=True)
# def pytest_configure(config):
#     # Create a unique timestamped filename
#     timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
#     report_dir = os.path.join(os.getcwd(), "reports")
#     os.makedirs(report_dir, exist_ok=True)
#
#     # Automatically set the html report path and options
#     config.option.htmlpath = os.path.join(report_dir, f"report_{timestamp}.html")
#     config.option.self_contained_html = True


@pytest.hookimpl(tryfirst=True)
def pytest_configure(config):
    timestamp = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    report_dir = os.path.join(os.getcwd(), "reports")
    os.makedirs(report_dir, exist_ok=True)

    report_path = os.path.join(report_dir, f"report_{timestamp}.html")
    config.option.htmlpath = report_path

import pytest
import os
from datetime import datetime

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()

    if rep.when == "call" and rep.failed:
        driver = item.funcargs.get("setup")
        screenshot_dir = item.funcargs.get("screenshot_dir")

        if driver and screenshot_dir:
            os.makedirs(screenshot_dir, exist_ok=True)
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            path = os.path.join(
                screenshot_dir,
                f"{item.name}_{timestamp}.png"
            )
            driver.save_screenshot(path)





