from selenium.webdriver.common.by import By


class formpage:
    click_cart_xpath = "//a[@data-test='shopping-cart-link']"
    click_checkout_id = "checkout"
    enter_firstname_id = "first-name"
    enter_lastname_id = "last-name"
    enter_zipcode_id = "postal-code"
    click_continue_id = "continue"
    click_finish_id = "finish"
    get_sucessmsg_xpath = "//h2[@data-test='complete-header']"

    def __init__(self, driver):
        self.driver = driver

    def click_cart(self):
        self.driver.find_element(By.XPATH, self.click_cart_xpath).click()

    def click_checkout(self):
        self.driver.find_element(By.ID, self.click_checkout_id).click()

    def enter_firstname(self, firstname):
        self.driver.find_element(By.ID, self.enter_firstname_id).send_keys(firstname)

    def enter_lastname(self, lastname):
        self.driver.find_element(By.ID, self.enter_lastname_id).send_keys(lastname)

    def enter_zipcode(self, zipcode):
        self.driver.find_element(By.ID, self.enter_zipcode_id).send_keys(zipcode)

    def click_continue(self):
        self.driver.find_element(By.ID, self.click_continue_id).click()

    def click_finish(self):
        self.driver.find_element(By.ID, self.click_finish_id).click()

    def get_success(self):
        getinnertext = self.driver.find_element(By.XPATH, self.get_sucessmsg_xpath).get_attribute("innerHTML")
        return getinnertext
