from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
import os
from time import sleep

class login:
    enter_username_id="user-name"
    enter_password_id="password"
    click_login_id="login-button"
    verify_login_xpath="//div[contains(text(),'Swag Labs')]"

    def __init__(self, driver):
        self.driver = driver

    def enter_username(self,username):
        self.driver.find_element(By.ID, self.enter_username_id).send_keys(username)

    def enter_password(self,password):
        self.driver.find_element(By.ID, self.enter_password_id).send_keys(password)

    def click_login(self):
        self.driver.find_element(By.ID, self.click_login_id).click()

    def verify_login(self):
        #sleep(300)
        WebDriverWait(self.driver, 10).until(
            EC.visibility_of_element_located((By.XPATH, self.verify_login_xpath))
        )
        return True



