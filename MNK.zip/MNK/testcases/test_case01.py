from faker import Faker
from PageObject.test_login import login
from PageObject.form_page import formpage
from ulitilites.readproperties import Readtestdata
from ulitilites import logger_config
import os
import pytest
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from time import sleep


class Testcase:

    def test_login(self, setup, screenshot_dir):
        logger = logger_config.get_logger(__name__)
        self.driver = setup
        self.path = screenshot_dir

        logger.info("Test execution started")

        url = Readtestdata.read_url()
        self.driver.get(url)
        logger.info(f"Navigated to URL: {url}")

        loginobj = login(self.driver)

        loginobj.enter_username(Readtestdata.get_username())
        loginobj.enter_password(Readtestdata.get_password())
        loginobj.click_login()
        try:
           ele=loginobj.verify_login()
           if ele:
              assert True
              logger.info("Login successful")
        except Exception as e:
            self.driver.save_screenshot(os.path.join(self.path, "order_failed.png"))
            assert False

    def test_form_submission(self, setup, screenshot_dir):
        logger = logger_config.get_logger(__name__)
        self.driver = setup
        self.path = screenshot_dir

        fake = Faker()

        firstname = fake.first_name()
        lastname = fake.last_name()
        zipcode = fake.postcode()

        logger.info("Starting form submission")

        try:
            formobj = formpage(self.driver)

            formobj.click_cart()
            formobj.click_checkout()

            formobj.enter_firstname("chandana")
            formobj.enter_lastname(lastname)
            formobj.enter_zipcode(zipcode)

            logger.info("Submitting order")
            formobj.click_continue()
            formobj.click_finish()

            success_msg = formobj.get_success()
            assert success_msg == "Thank you for your order!!!"

            logger.info("Order placed successfully")

        except Exception as e:
            logger.error(f"Order placement failed: {e}")
            self.driver.save_screenshot(
                os.path.join(self.path, "order_failed.png")
            )
            raise
