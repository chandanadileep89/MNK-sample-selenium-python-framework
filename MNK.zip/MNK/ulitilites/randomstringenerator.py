import random
import string

def randomstring(length=9):
    char=string.ascii_letters+string.digits
    return ''.join(random.choice(char) for i in range(length))
print(randomstring())