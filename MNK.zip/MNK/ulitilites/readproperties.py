import configparser
import os

config=configparser.RawConfigParser()
config.read(os.path.abspath(os.curdir)+"\\configurations\\config.txt")


class Readtestdata:
      @staticmethod
      def read_url():
          url=config.get("commondata","url")
          return url

      @staticmethod
      def get_username():
          username=config.get("commondata","username")
          return username

      @staticmethod
      def get_password():
          password=config.get("commondata","password")
          return password
